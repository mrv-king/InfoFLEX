/******************************************************************************
*
* (c) 2020 	by SystemCORP Energy Pty Ltd
*
*******************************************************************************
*
* Disclaimer: This program is an example and should be used as such.
*             If you wish to use this program or parts of it in your application,
*             you must validate the code yourself.  SystemCORP Embedded Technology
*             Pty Ltd can not be held responsible for the correct functioning
*			  or coding of this example.
*******************************************************************************/

/*****************************************************************************/
/*!	\file		MainClient.h
 *	\brief 		Header file for the PIS10 Stack Example
 *	\par 		SystemCORP Pty Ltd
 *
 *				15/50 William Street,
 *				Beckenham,
 *				Perth, WA 6107,
 *				Australia.
 *
 *				Phone	: +61 (8) 9258 4683
 *				Fax		: +61 (8) 9258 4673
 *				Email	: support@systemcorp.com.au
 */
/*****************************************************************************/

/******************************************************************************
*	Defines
******************************************************************************/

#ifndef MAIN_CLIENT_INCLUDED
#define MAIN_CLIENT_INCLUDED 1

/******************************************************************************
*	Includes
******************************************************************************/

#include <stdio.h>
#include <stdlib.h>

#include "IEC61850Types.h"
#include "IEC61850API.h"
#include "sysctype.h"

#include "PIS10CreateServerClient.h"
#include "IEC61850Functions.h"
#include "LocalData.h"
#include "ExampleTypes.h"
#include "PrintView.h"
#include "UserInput.h"

/******************************************************************************
*	Prototypes
******************************************************************************/

enum IEC61850_ErrorCodes setupIEC61850Client(void);

#endif
