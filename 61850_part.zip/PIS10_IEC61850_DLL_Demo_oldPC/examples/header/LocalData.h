/******************************************************************************
*
* (c) 2020 	by SystemCORP Energy Pty Ltd
*
*******************************************************************************
*
* Disclaimer: This program is an example and should be used as such.
*             If you wish to use this program or parts of it in your application,
*             you must validate the code yourself.  SystemCORP Embedded Technology
*             Pty Ltd can not be held responsible for the correct functioning
*			  or coding of this example.
*******************************************************************************/

/*****************************************************************************/
/*!	\file		LocalData.h
 *	\brief 		Header file for the PIS10 Stack Example
 *	\par 		SystemCORP Pty Ltd
 *
 *				15/50 William Street,
 *				Beckenham,
 *				Perth, WA 6107,
 *				Australia.
 *
 *				Phone	: +61 (8) 9258 4683
 *				Fax		: +61 (8) 9258 4673
 *				Email	: support@systemcorp.com.au
 */
/*****************************************************************************/

/******************************************************************************
*	Defines
******************************************************************************/

#ifndef LOCAL_DATA_INCLUDED
#define LOCAL_DATA_INCLUDED 1

#define SIZE_OF_PDIF_ARRAY 6
#define SIZE_OF_ERROR_STRING 255

/* Needed to make snprintf work in Visual Studio */
#ifdef _MSC_VER
	#if _MSC_VER
	   #define snprintf _snprintf
	#endif
#endif
/******************************************************************************
*	Includes
******************************************************************************/

#include <stdio.h>
#include "IEC61850Types.h"
#include "sysctype.h"

#include "ExampleTypes.h"

/******************************************************************************
*	Prototypes
******************************************************************************/
/* CSWI */
Boolean GetCSWICtlVal(void);
Boolean SetCSWICtlVal(Boolean inCtlVal);
enum DbPosValues GetCSWIStVal(void);
enum DbPosValues SetCSWIStVal(enum DbPosValues inStVal);

/* GGIO */
Boolean GetGGIOCtlVal(void);
Boolean SetGGIOCtlVal(Boolean inCtlVal);
Boolean GetGGIOStVal(void);
Boolean SetGGIOStVal(Boolean inStVal);

/* MMXU */
Integer32 GetMMXUPhsAMagi(void);
Integer32 SetMMXUPhsAMagi(Integer32 inPhsMagi);
Integer32 GetMMXUPhsBMagi(void);
Integer32 SetMMXUPhsBMagi(Integer32 inPhsMagi);
Integer32 GetMMXUPhsCMagi(void);
Integer32 SetMMXUPhsCMagi(Integer32 inPhsMagi);

/* PDIF */
CrvPts GetPDIFCrvPts(Integer8 inIndex);
CrvPts SetPDIFCrvPts(Integer8 inIndex, CrvPts inCrvPts);

/* ErrorString*/
char* GetErrorString(void);
char* SetErrorString(char* inErrorString, Unsigned16 inLength);

#endif
