/******************************************************************************
*
* (c) 2020 	by SystemCORP Energy Pty Ltd
*
*******************************************************************************
*
* Disclaimer: This program is an example and should be used as such.
*             If you wish to use this program or parts of it in your application,
*             you must validate the code yourself.  SystemCORP Embedded Technology
*             Pty Ltd can not be held responsible for the correct functioning
*			  or coding of this example.
*******************************************************************************/

/*****************************************************************************/
/*!	\file		PIS10CreateServerClient.h
 *	\brief 		C Source code file for the PIS10 Stack Example
 *	\par 		SystemCORP Pty Ltd
 *
 *				15/50 William Street,
 *				Beckenham,
 *				Perth, WA 6107,
 *				Australia.
 *
 *				Phone	: +61 (8) 9258 4683
 *				Fax		: +61 (8) 9258 4673
 *				Email	: support@systemcorp.com.au
 */
/*****************************************************************************/

/******************************************************************************
*	Defines
******************************************************************************/


#ifndef CLIENT_SERVER_FUNCTIONS_INCLUDED
#define CLIENT_SERVER_FUNCTIONS_INCLUDED 1

/******************************************************************************
*	Includes
******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

#include "IEC61850Types.h"
#include "IEC61850API.h"
#include "sysctype.h"

#include "PIS10Callbacks.h"

/******************************************************************************
*	Prototypes
******************************************************************************/

enum IEC61850_ErrorCodes CreateServer(unsigned long int uiOptions);

enum IEC61850_ErrorCodes CreateClient(void);

IEC61850 GetMyServerClient(void);

int IsMyServerClientNULL(void);

enum IEC61850_ErrorCodes  LoadSCLFile(char *pPath);

enum IEC61850_ErrorCodes StartMyServerClient(void);

enum IEC61850_ErrorCodes StopMyServerClient(void);

enum IEC61850_ErrorCodes FreeMyServerClient(void);

enum IEC61850_ErrorCodes SetUserData(void * inData);

enum IEC61850_ErrorCodes SetControlsOrCat();

#endif
