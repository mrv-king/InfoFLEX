/******************************************************************************
*
* (c) 2020 	by SystemCORP Energy Pty Ltd
*
*******************************************************************************
*
* Disclaimer: This program is an example and should be used as such.
*             If you wish to use this program or parts of it in your application,
*             you must validate the code yourself.  SystemCORP Embedded Technology
*             Pty Ltd can not be held responsible for the correct functioning
*			  or coding of this example.
*******************************************************************************/

/*****************************************************************************/
/*!	\file		UserInput.h
 *	\brief 		Header file for the PIS10 Stack Example
 *	\par 		SystemCORP Pty Ltd
 *
 *				15/50 William Street,
 *				Beckenham,
 *				Perth, WA 6107,
 *				Australia.
 *
 *				Phone	: +61 (8) 9258 4683
 *				Fax		: +61 (8) 9258 4673
 *				Email	: support@systemcorp.com.au
 */
/*****************************************************************************/

/******************************************************************************
*	Defines
******************************************************************************/

#ifndef USER_INPUT_INCLUDED
#define USER_INPUT_INCLUDED 1

/******************************************************************************
*	Includes
******************************************************************************/

#include <stdio.h>
#include "ExampleTypes.h"
#include "LocalData.h"

/******************************************************************************
*	Prototypes
******************************************************************************/
enum UserCommands GetServerCommandFromUser(void);
enum UserCommands GetClientCommandFromUser(void);
Boolean GetBooleanFromUser(void);
Integer32 GetInteger32FromUser(void);
Integer8 GetIndexForArray(void);
Float32 GetFloat32FromUser(void);

#endif
