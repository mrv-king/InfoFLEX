/******************************************************************************
*
* (c) 2020 	by SystemCORP Energy Pty Ltd
*
*******************************************************************************
*
* Disclaimer: This program is an example and should be used as such.
*             If you wish to use this program or parts of it in your application,
*             you must validate the code yourself.  SystemCORP Embedded Technology
*             Pty Ltd can not be held responsible for the correct functioning
*			  or coding of this example.
*******************************************************************************/

/*****************************************************************************/
/*!	\file		IEC61850Functions.h
*	\brief 		C header file for the PIS10 Stack Example
*	\par 		SystemCORP Pty Ltd
*
*				15/50 William Street,
*				Beckenham,
*				Perth, WA 6107,
*				Australia.
*
*				Phone	: +61 (8) 9258 4683
*				Fax		: +61 (8) 9258 4673
*				Email	: support@systemcorp.com.au
*/
/*****************************************************************************/

/******************************************************************************
*	Defines
******************************************************************************/


#ifndef IEC61850_FUNCTIONS_INCLUDED
#define IEC61850_FUNCTIONS_INCLUDED 1



/******************************************************************************
*	Includes
******************************************************************************/

#include <stdio.h>

#include "IEC61850Types.h"
#include "IEC61850API.h"
#include "sysctype.h"

#include "LocalData.h"
#include "PIS10CreateServerClient.h"

/******************************************************************************
*	Prototypes
******************************************************************************/
enum IEC61850_ErrorCodes SelectCSWI(Boolean inCtrlValue);
enum IEC61850_ErrorCodes OperateCSWI(Boolean inCtrlValue);

enum IEC61850_ErrorCodes SelectGGIO(Boolean inCtrlValue);
enum IEC61850_ErrorCodes OperateGGIO(Boolean inCtrlValue);

enum IEC61850_ErrorCodes UpdateMMXUPhsAMagi(Integer32 inUpdateValue);
enum IEC61850_ErrorCodes UpdateMMXUPhsBMagi(Integer32 inUpdateValue);
enum IEC61850_ErrorCodes UpdateMMXUPhsCMagi(Integer32 inUpdateValue);

enum IEC61850_ErrorCodes UpdatePDIFCrvPts(CrvPts inUpdateValue, Integer8 inIndex);

enum IEC61850_ErrorCodes MMSGetConnectionsList(void);
enum IEC61850_ErrorCodes MMSGetFileAttribs(void);
enum IEC61850_ErrorCodes MMSGetFile(void);
enum IEC61850_ErrorCodes MMSDeleteFile(void);

#endif
