/******************************************************************************
*
* (c) 2020 	by SystemCORP Energy Pty Ltd
*
*******************************************************************************
*
* Disclaimer: This program is an example and should be used as such.
*             If you wish to use this program or parts of it in your application,
*             you must validate the code yourself.  SystemCORP Embedded Technology
*             Pty Ltd can not be held responsible for the correct functioning
*			  or coding of this example.
*******************************************************************************/

/*****************************************************************************/
/*!	\file		PIS10Callbacks.h
*	\brief 		C header file for the PIS10 Stack Example
*	\par 		SystemCORP Pty Ltd
*
*				15/50 William Street,
*				Beckenham,
*				Perth, WA 6107,
*				Australia.
*
*				Phone	: +61 (8) 9258 4683
*				Fax		: +61 (8) 9258 4673
*				Email	: support@systemcorp.com.au
*/
/*****************************************************************************/

/******************************************************************************
*	Defines
******************************************************************************/


#ifndef CALLBACK_FUNCTIONS_INCLUDED
#define CALLBACK_FUNCTIONS_INCLUDED 1

/******************************************************************************
*	Includes
******************************************************************************/
#include <stdio.h>
#include <math.h>

#include "IEC61850Types.h"
#include "IEC61850API.h"
#include "sysctype.h"

#include "PIS10CreateServerClient.h"
#include "LocalData.h"
#include "PrintView.h"

/******************************************************************************
*	Prototypes
******************************************************************************/


//Read Callback
enum IEC61850_CallbackReturnServiceErrorCodes ReadCallbackHandler( void *ptUserData, const struct IEC61850_DataAttributeID *ptDataAttributeID, struct IEC61850_DataAttributeData *ptReturnedValue);

//Write Callback
enum IEC61850_CallbackReturnServiceErrorCodes  WriteCallbackHandler(void * ptUserData, const struct IEC61850_DataAttributeID * ptDataAttributeID, const struct IEC61850_DataAttributeData * ptNewValue);

//Select Callback                           
enum eCommandAddCause  SelectCallbackHandler(void * ptUserData, const struct IEC61850_DataAttributeID * ptControlID, const struct IEC61850_DataAttributeData * ptSelectValue, const struct IEC61850_CommandParameters* ptSelectParameters);

//Operate Callback
enum eCommandAddCause  OperateCallbackHandler(void * ptUserData, const struct IEC61850_DataAttributeID * ptControlID, const struct IEC61850_DataAttributeData * ptOperateValue, const struct IEC61850_CommandParameters* ptOperateParameters);

//Cancel Callback
enum eCommandAddCause  CancelCallbackHandler( void *ptUserData, const struct IEC61850_DataAttributeID * ptControlID, const struct IEC61850_CommandParameters* ptCancelParameters);

//Update Callback
void  UpdateCallbackHandler( void *ptUserData, const struct IEC61850_DataAttributeID * ptControlID, const struct IEC61850_DataAttributeData *ptNewValue);

//Error Callback
enum eCommandAddCause ErrorCallbackHandler(void * ptUserData, const struct IEC61850_DataAttributeID * ptControlID, const struct IEC61850_ErrorParameters * ptErrorParamtrs);

//Operative Test Callback
enum eCommandAddCause OperativeTestCallbackHandler(void * ptUserData, const struct IEC61850_DataAttributeID * ptControlID, const struct IEC61850_CommandParameters* ptOperativeTestParameters);

//Questionable Data Point Callback
void QuestionableCallbackHandler(void * ptUserData, const struct IEC61850_DataAttributeID * ptDataAttributeID);

//Command Termination Callback
enum eCommandAddCause CommandTerminationCallback(void * ptUserData, const struct IEC61850_DataAttributeID * ptControlID, const struct IEC61850_DataAttributeData * ptCmdTermValue);

enum IEC61850_FileResponseCode FileCallbackHandler(void * ptUserData, enum IEC61850_FileCallType fileCallType, struct tFileAttr* ptFileAttributes);

#endif
