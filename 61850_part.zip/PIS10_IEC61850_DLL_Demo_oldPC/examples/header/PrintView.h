/******************************************************************************
*
* (c) 2020 	by SystemCORP Energy Pty Ltd
*
*******************************************************************************
*
* Disclaimer: This program is an example and should be used as such.
*             If you wish to use this program or parts of it in your application,
*             you must validate the code yourself.  SystemCORP Embedded Technology
*             Pty Ltd can not be held responsible for the correct functioning
*			  or coding of this example.
*******************************************************************************/

/*****************************************************************************/
/*!	\file		PrintView.h
 *	\brief 		Header file for the PIS10 Stack Example
 *	\par 		SystemCORP Pty Ltd
 *
 *				15/50 William Street,
 *				Beckenham,
 *				Perth, WA 6107,
 *				Australia.
 *
 *				Phone	: +61 (8) 9258 4683
 *				Fax		: +61 (8) 9258 4673
 *				Email	: support@systemcorp.com.au
 */
/*****************************************************************************/

/******************************************************************************
*	Defines
******************************************************************************/

#ifndef PRINT_VIEW_INCLUDED
#define PRINT_VIEW_INCLUDED 1

/******************************************************************************
*	Includes
******************************************************************************/

#include <stdio.h>
#include "IEC61850API.h"
#include "sysctype.h"
#include "ExampleTypes.h"

#include "LocalData.h"

/******************************************************************************
*	Prototypes
******************************************************************************/

void PrintServerFullView(void);
void PrintClientFullView(void);
void PrintServerSubscriptionFullView(void);

void PrintServerHeader(void);
void PrintClientHeader(void);
void PrintServerSubscriptionHeader(void);

void PrintDataView(void);
void PrintServerSubscriptionDataView(void);

void PrintErrorString(void);
void PrintServerMenuView(void);
void PrintClientMenuView(void);
void PrintServerSubscriptionMenuView(void);

const char* BooleanToString(Boolean inBool);
const char* DBPosToString(enum DbPosValues inDBPosVal);
void ClearScreen(void);


#endif
