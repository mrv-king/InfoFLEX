﻿using System;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Data.OleDb;
using System.Globalization;
using System.Diagnostics;

namespace dispatcher_control_point
{
    public partial class Form1 : Form
    {
        IPEndPoint ipep, ipep2;
        UdpClient newsock, newsock2;
        IPEndPoint server_61850;
        IPEndPoint server_OCPP;
        IPEndPoint server_OpenADR;

        OleDbConnection conn;
        OleDbDataAdapter oledbAdapter = new OleDbDataAdapter();

        int graphX_counter = 0;
        int[] posX = new int[60];

        int grid_power = 0;
        int photovaltaic_power = 0;
        int battery_power = 0;

        int reference_power_level = 0;


        bool pictureBox6_pos = false;
        bool pictureBox7_pos = false;
        bool pictureBox8_pos = false;
        bool pictureBox9_pos = false;

        Process process = null;
        public Form1()
        {


            ipep = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8080);
            newsock = new UdpClient(ipep);
            server_61850 = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8081);
            server_OCPP = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8082);
            server_OpenADR = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8083);


            ipep2 = new IPEndPoint(IPAddress.Parse("192.168.10.98"), 8085);
            newsock2 = new UdpClient(ipep2);

            Thread MyThread = null;
            Thread MyThread2 = null;
            try 
            {
                ThreadStart ThreadMethod_Recv = new ThreadStart(forever_listen);
                MyThread = new Thread(ThreadMethod_Recv);

                ThreadStart ThreadMethod_Recv2 = new ThreadStart(forever_listen_61850);
                MyThread2 = new Thread(ThreadMethod_Recv2);
            }
            catch (Exception ex) 
            {
                MessageBox.Show("Failed to create thread with error" + ex.Message);
                return;
            }
            try
            {
                MyThread.Start();
                MyThread2.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show("The thread failed to start with error:" + ex.Message);
            }
            InitializeComponent();
            
            ProcessStartInfo ocpp_process = new ProcessStartInfo();
            ocpp_process.FileName = @"C:\Users\nikgal-local\AppData\Local\Programs\Python\Python38-32\python.exe";
            var ocpp_script = @"C:\Users\nikgal-local\Desktop\OCPP_python_WINDOWS\windows_ocpp\windows_ocpp.py";
            ocpp_process.Arguments = $"\"{ocpp_script}\"";

            ocpp_process.UseShellExecute = false;
            ocpp_process.CreateNoWindow = false;

            using (process = Process.Start(ocpp_process));

            ProcessStartInfo openadr_process = new ProcessStartInfo();
            openadr_process.FileName = @"C:\Users\nikgal-local\AppData\Local\Programs\Python\Python38-32\python.exe";
            var openadr_script = @"C:\Users\nikgal-local\Desktop\OPENADR\OpenADR Python application Visual Studio\my_openadr_ver_0.5.16\my_openadr_ver_0.5.16.py";
            openadr_process.Arguments = $"\"{openadr_script}\"";

            openadr_process.UseShellExecute = false;
            openadr_process.CreateNoWindow = true;

            using (process = Process.Start(openadr_process));


            utility_power.BackColor = Color.LightGreen;
        }

        private void forever_listen_61850()
        {
            byte[] data = new byte[1024];
            string recv_message = "";
            string protocol_name = "";
            string command_name = "";
            string variable_name = "";

            int start_index, stop_index = 0;

            IPEndPoint server2 = new IPEndPoint(IPAddress.Parse("192.168.10.98"), 8085);
            while (true)
            {
                data = newsock2.Receive(ref server2);
                recv_message = Encoding.ASCII.GetString(data, 0, data.Length);
                
                protocol_name = recv_message.Substring(0, 4);
                switch (protocol_name)
                {
                    case "6185":
                        start_index = recv_message.Substring("61850:".Length, recv_message.Length - "61850:".Length).IndexOf(":");
                        command_name = recv_message.Substring("61850:".Length, recv_message.Length - (recv_message.Length - start_index)); //command definition
                        switch (command_name)
                        {
                            case "MMXU_WRITE":
                                start_index = recv_message.IndexOf("MMXU_WRITE:");
                                recv_message = recv_message.Substring(start_index + "MMXU_WRITE:".Length, recv_message.Length - start_index - "MMXU_WRITE:".Length);
                                start_index = recv_message.IndexOf(":");
                                variable_name = recv_message.Substring(0, start_index);    
                                if (variable_name == "utility_power")
                                {
                                    recv_message = recv_message.Substring(start_index + 1, recv_message.Length - start_index - 1);
                                    this.Invoke(new MethodInvoker(() => utility_power.Text = "Power: " + recv_message));
                                    utility_power.BackColor = Color.LightGreen;
                                }
                                break;
                            default:
                                break;
                        }
                        break;
                    default:
                        MessageBox.Show("unknown protocol name!");
                        break;
                }
            }
        }


        private void forever_listen()
        {
            byte[] data = new byte[1024];
            string recv_message = "";
            string protocol_name = "";
            string command_name = "";

            int start_index, stop_index = 0;

            IPEndPoint server = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 0);
            while (true)
            {
                data = newsock.Receive(ref server);
                recv_message = Encoding.ASCII.GetString(data, 0, data.Length);
                protocol_name = recv_message.Substring(0, 4);
                switch (protocol_name)
                {
                    case "ocpp":
                        start_index = recv_message.Substring("ocpp:".Length, recv_message.Length - "ocpp:".Length).IndexOf(":");
                        command_name = recv_message.Substring("ocpp:".Length, recv_message.Length - (recv_message.Length - start_index)); //command definition
                        switch (command_name)
                        {
                            case "bootNotification":
                                start_index = recv_message.IndexOf("{model:");
                                recv_message = recv_message.Substring(start_index, recv_message.Length - start_index);
                                start_index = recv_message.IndexOf(",");
                                if (start_index > 1)
                                {
                                    this.Invoke(new MethodInvoker(() => bat_model_label.Text = recv_message.Substring("{model:".Length, recv_message.Length - (recv_message.Length - start_index)-"{model:".Length)));
                                    bat_model_label.BackColor = Color.LightGreen;
                                }
                                else
                                {
                                    this.Invoke(new MethodInvoker(() => bat_model_label.Text = "no model"));
                                    bat_model_label.BackColor = Color.LightCoral;
                                }
                                start_index = recv_message.IndexOf("vendor_name:");
                                stop_index = recv_message.IndexOf("}");
                                recv_message = recv_message.Substring(start_index + "vendor_name:".Length, stop_index - start_index - "vendor_name:".Length);
                                if (recv_message.Length > 3)
                                {
                                    this.Invoke(new MethodInvoker(() => bat_vendor_label.Text = recv_message));
                                    bat_vendor_label.BackColor = Color.LightGreen;
                                }
                                else
                                {
                                    this.Invoke(new MethodInvoker(() => bat_vendor_label.Text = "no model"));
                                    bat_vendor_label.BackColor = Color.LightCoral;
                                }
                                break;
                            case "setVariables":
                                start_index = recv_message.IndexOf("variable:");
                                recv_message = recv_message.Substring(start_index, recv_message.Length - start_index);
                                stop_index = recv_message.IndexOf(",");
                                switch (recv_message.Substring("variable:".Length, stop_index - "variable:".Length))
                                {
                                    case "power":
                                        start_index = recv_message.IndexOf("attribute_value:") + "attribute_value:".Length;
                                        stop_index = recv_message.IndexOf("}");
                                        battery_power = Int32.Parse(recv_message.Substring(start_index, stop_index - start_index));
                                        this.Invoke(new MethodInvoker(() => bat_power_label.Text = "Power: " + recv_message.Substring(start_index, stop_index - start_index)));
                                        bat_power_label.BackColor = Color.LightGreen;
                                        break;
                                    default:
                                        MessageBox.Show("Unknown variable name", "OCPP");
                                        break;
                                }
                                break;
                            default:
                                MessageBox.Show("Unknown command name!", "OCPP");
                                break;
                        }
                        break;
                    case "oadr":
                        start_index = recv_message.Substring("oadr:".Length, recv_message.Length - "oadr:".Length).IndexOf(":");
                        command_name = recv_message.Substring("oadr:".Length, recv_message.Length - (recv_message.Length - start_index)); //command definition
                        switch (command_name)
                        {
                            case "on_create_party_registration":
                                start_index = recv_message.IndexOf("{ven_name:");
                                recv_message = recv_message.Substring(start_index, recv_message.Length - start_index);
                                start_index = recv_message.IndexOf(",");
                                if (start_index > 1)
                                {
                                    this.Invoke(new MethodInvoker(() => grid_ven_name_label.Text = recv_message.Substring("{ven_name:".Length, recv_message.Length - (recv_message.Length - start_index) - "{ven_name:".Length)));
                                    grid_ven_name_label.BackColor = Color.LightGreen;
                                }
                                else
                                {
                                    this.Invoke(new MethodInvoker(() => grid_ven_name_label.Text = "no vendor"));
                                    grid_ven_name_label.BackColor = Color.LightCoral;
                                }
                                start_index = recv_message.IndexOf("ven_id:");
                                recv_message = recv_message.Substring(start_index, recv_message.Length - start_index);
                                start_index = recv_message.IndexOf(",");
                                if (recv_message.Length > 3)
                                {
                                    this.Invoke(new MethodInvoker(() => grid_ven_id_label.Text = recv_message.Substring("ven_id:".Length, recv_message.Length - (recv_message.Length - start_index) - "ven_id:".Length)));
                                    grid_ven_id_label.BackColor = Color.LightGreen;
                                }
                                else
                                {
                                    this.Invoke(new MethodInvoker(() => grid_ven_id_label.Text = "no id"));
                                    grid_ven_id_label.BackColor = Color.LightCoral;
                                }
                                start_index = recv_message.IndexOf("registration_id:");
                                recv_message = recv_message.Substring(start_index, recv_message.Length - start_index - "}".Length);
                                if (recv_message.Length > 3)
                                {
                                    this.Invoke(new MethodInvoker(() => grid_reg_id_label.Text = recv_message.Substring("registration_id:".Length, recv_message.Length - "registration_id:".Length)));
                                    grid_reg_id_label.BackColor = Color.LightGreen;
                                }
                                else
                                {
                                    this.Invoke(new MethodInvoker(() => grid_reg_id_label.Text = "no reg. id"));
                                    grid_reg_id_label.BackColor = Color.LightCoral;
                                }
                                break;
                            case "on_update_report":
                                start_index = recv_message.IndexOf("{ven_id:");
                                recv_message = recv_message.Substring(start_index, recv_message.Length - start_index);
                                start_index = recv_message.IndexOf(",");
                                if (grid_ven_id_label.Text == recv_message.Substring("{ven_id:".Length, recv_message.Length - (recv_message.Length - start_index) - "{ven_id:".Length))
                                {
                                    start_index = recv_message.IndexOf("measurement:");
                                    recv_message = recv_message.Substring(start_index, recv_message.Length - start_index);
                                    start_index = recv_message.IndexOf(",");
                                    if (recv_message.Length > 3)
                                    {
                                        switch (recv_message.Substring("measurement:".Length, recv_message.Length - (recv_message.Length - start_index) - "measurement:".Length))
                                        {
                                            case "Voltage":
                                                start_index = recv_message.IndexOf("value:");
                                                recv_message = recv_message.Substring(start_index + "value:".Length, recv_message.Length - start_index - "value:".Length - "}".Length);
                                                if (recv_message.Length > 3)
                                                {
                                                    //this.Invoke(new MethodInvoker(() => voltage_label.Text = "Voltage: " + recv_message));
                                                    //voltage_label.BackColor = Color.LightGreen;
                                                }
                                                else
                                                {
                                                    //this.Invoke(new MethodInvoker(() => voltage_label.Text = "Voltage: "));
                                                    //voltage_label.BackColor = Color.LightCoral;
                                                }
                                                break;
                                            case "energyReal":
                                                start_index = recv_message.IndexOf("value:");
                                                recv_message = recv_message.Substring(start_index + "value:".Length, recv_message.Length - start_index - "value:".Length - "}".Length);
                                                this.Invoke(new MethodInvoker(() => pv_power.Text = "Power: " + recv_message));
                                                pv_power.BackColor = Color.LightGreen;
                                                break;
                                            case "currencyPerKWh":
                                                start_index = recv_message.IndexOf("value:");
                                                recv_message = recv_message.Substring(start_index + "value:".Length, recv_message.Length - start_index - "value:".Length - "}".Length);
                                                if (recv_message.Length > 3)
                                                {
                                                    //this.Invoke(new MethodInvoker(() => energy_price_label.Text = "Energy $: " + recv_message));
                                                    //energy_price_label.BackColor = Color.LightGreen;
                                                }
                                                else
                                                {
                                                    //this.Invoke(new MethodInvoker(() => energy_price_label.Text = "Energy $: "));
                                                    //energy_price_label.BackColor = Color.LightCoral;
                                                }
                                                break;
                                            default:
                                                //MessageBox.Show("Unknown measurements!", "OpenADR");
                                                break;
                                        }
                                        grid_ven_id_label.BackColor = Color.LightGreen;
                                    }
                                    else
                                    {
                                        MessageBox.Show("The measurement id is too short!", "OpenADR");
                                    }
                                }
                                else
                                    MessageBox.Show("veb_id's are not identical");
                                
                                break;
                            default:
                                //MessageBox.Show("Unknown command name!", "OpenADR");
                                break;
                        }
                        break;
                    case "6185":
                        break;
                    default:
                        //MessageBox.Show("unknown protocol name!");
                        break;
                }
            }
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            byte[] data = new byte[1024];
            if (pictureBox6_pos)
            {
                pictureBox6.Image = Properties.Resources.open_switch;
                pictureBox6_pos = false;
            }
            else
            {
                pictureBox6.Image = Properties.Resources.closed_switch;
                pictureBox6_pos = true;
            }
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            chart1.Series.Clear();
            chart2.Series.Clear();
            chart3.Series.Clear();
            chart4.Series.Clear();

            timer1.Stop();
            timer1.Enabled = false;
            timer1.Enabled = true;
            timer1.Start();
            if (tabControl1.SelectedIndex == 4)
            {

                chart1.Series.Clear();
                var chart = chart1.ChartAreas[0];
                chart.AxisX.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Number;
                chart.AxisX.LabelStyle.Format = "";
                chart.AxisY.LabelStyle.Format = "";
                chart.AxisY.LabelStyle.IsEndLabelVisible = false;
                chart.AxisX.Minimum = 0;
                chart.AxisX.Maximum = 60;
                chart.AxisY.Maximum = 12000;
                chart.AxisY.Minimum = -1000;
                chart.AxisX.Interval = 5;
                chart.AxisY.Interval = 1000;
                chart1.Series.Add("Battery Graph");
                chart1.Series["Battery Graph"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
                chart1.Series["Battery Graph"].Color = Color.Red;
                chart1.Series["Battery Graph"].IsVisibleInLegend = false;
            }
            else if (tabControl1.SelectedIndex == 1)
            {
                chart2.Series.Clear();
                var chart = chart2.ChartAreas[0];
                chart.AxisX.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Number;
                chart.AxisX.LabelStyle.Format = "";
                chart.AxisY.LabelStyle.Format = "";
                chart.AxisY.LabelStyle.IsEndLabelVisible = false;
                chart.AxisX.Minimum = 0;
                chart.AxisX.Maximum = 60;
                chart.AxisY.Maximum = 1000;
                chart.AxisY.Minimum = -12000;
                chart.AxisX.Interval = 5;
                chart.AxisY.Interval = 1000;
                chart2.Series.Add("Utility Graph");
                chart2.Series["Utility Graph"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
                chart2.Series["Utility Graph"].Color = Color.Red;
                chart2.Series["Utility Graph"].IsVisibleInLegend = false;
            }
            else if (tabControl1.SelectedIndex == 2)
            {
                chart3.Series.Clear();
                var chart = chart3.ChartAreas[0];
                chart.AxisX.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Number;
                chart.AxisX.LabelStyle.Format = "";
                chart.AxisY.LabelStyle.Format = "";
                chart.AxisY.LabelStyle.IsEndLabelVisible = false;
                chart.AxisX.Minimum = 0;
                chart.AxisX.Maximum = 60;
                chart.AxisY.Maximum = 22000;
                chart.AxisY.Minimum = -2000;
                chart.AxisX.Interval = 5;
                chart.AxisY.Interval = 2000;
                chart3.Series.Add("PV Graph");
                chart3.Series["PV Graph"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
                chart3.Series["PV Graph"].Color = Color.Red;
                chart3.Series["PV Graph"].IsVisibleInLegend = false;
            }
            else if (tabControl1.SelectedIndex == 3)
            {
                chart4.Series.Clear();
                var chart = chart4.ChartAreas[0];
                chart.AxisX.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Number;
                chart.AxisX.LabelStyle.Format = "";
                chart.AxisY.LabelStyle.Format = "";
                chart.AxisY.LabelStyle.IsEndLabelVisible = false;
                chart.AxisX.Minimum = 0;
                chart.AxisX.Maximum = 60;
                chart.AxisY.Maximum = 40000;
                chart.AxisY.Minimum = -2000;
                chart.AxisX.Interval = 5;
                chart.AxisY.Interval = 5000;
                chart4.Series.Add("Load Graph");
                chart4.Series["Load Graph"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
                chart4.Series["Load Graph"].Color = Color.Red;
                chart4.Series["Load Graph"].IsVisibleInLegend = false;
            }
            else
            {
                chart1.Series.Clear();
                chart2.Series.Clear();
                chart3.Series.Clear();
                chart4.Series.Clear();

                timer1.Stop();
                timer1.Enabled = false;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            battery_power = int.Parse(bat_power_label.Text.Substring("Power: ".Length, bat_power_label.Text.Length - "Power: ".Length));
            grid_power = int.Parse(utility_power.Text.Substring("Power: ".Length, utility_power.Text.Length - "Power: ".Length));
            photovaltaic_power = int.Parse(pv_power.Text.Substring("Power: ".Length, pv_power.Text.IndexOf(".") - "Power: ".Length));
            int load_power_consumption = battery_power + photovaltaic_power - grid_power;
            if (graphX_counter > 60)
                graphX_counter = 0;
            else
                graphX_counter += 1;

            if (tabControl1.SelectedIndex == 4)
            {
                if (graphX_counter == 0)
                {
                    chart1.Series.Clear();
                    chart1.Series.Add("Battery Graph");
                    chart1.Series["Battery Graph"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
                    chart1.Series["Battery Graph"].Color = Color.Red;
                    chart1.Series["Battery Graph"].IsVisibleInLegend = false;
                }
                chart1.Series["Battery Graph"].Points.AddXY(graphX_counter, battery_power);
            }    
            else if(tabControl1.SelectedIndex == 1)
            {
                if (graphX_counter == 0)
                {
                    chart2.Series.Clear();
                    chart2.Series.Add("Utility Graph");
                    chart2.Series["Utility Graph"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
                    chart2.Series["Utility Graph"].Color = Color.Red;
                    chart2.Series["Utility Graph"].IsVisibleInLegend = false;
                }
                chart2.Series["Utility Graph"].Points.AddXY(graphX_counter, grid_power);
            }
            else if (tabControl1.SelectedIndex == 2)
            {
                if (graphX_counter == 0)
                {
                    chart3.Series.Clear();
                    chart3.Series.Add("PV Graph");
                    chart3.Series["PV Graph"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
                    chart3.Series["PV Graph"].Color = Color.Red;
                    chart3.Series["PV Graph"].IsVisibleInLegend = false;
                }
                chart3.Series["PV Graph"].Points.AddXY(graphX_counter, photovaltaic_power);
            }
            else if (tabControl1.SelectedIndex == 3)
            {
                if (graphX_counter == 0)
                {
                    chart4.Series.Clear();
                    chart4.Series.Add("Load Graph");
                    chart4.Series["Load Graph"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
                    chart4.Series["Load Graph"].Color = Color.Red;
                    chart4.Series["Load Graph"].IsVisibleInLegend = false;
                }
                chart4.Series["Load Graph"].Points.AddXY(graphX_counter, load_power_consumption);
            }

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            battery_power = int.Parse(bat_power_label.Text.Substring("Power: ".Length, bat_power_label.Text.Length - "Power: ".Length));
            grid_power = int.Parse(utility_power.Text.Substring("Power: ".Length, utility_power.Text.Length - "Power: ".Length));
            photovaltaic_power = int.Parse(pv_power.Text.Substring("Power: ".Length, pv_power.Text.IndexOf(".") - "Power: ".Length));
            int load_power_consumption = battery_power + photovaltaic_power - grid_power;
            load_pow.Text = "Power: " + load_power_consumption.ToString();
            if (battery_power > 10000)
            {
                reference_power_level -= 1;
                byte[] data = new byte[1024];
                data = Encoding.ASCII.GetBytes("ocpp:set_variable:power:" + reference_power_level.ToString());
                newsock.Send(data, data.Length, server_OCPP);
            }
            else if (battery_power > 9000 && battery_power < 10000)
            {
                reference_power_level += 1;
                byte[] data = new byte[1024];
                data = Encoding.ASCII.GetBytes("ocpp:set_variable:power:" + reference_power_level.ToString());
                newsock.Send(data, data.Length, server_OCPP);
            }
            else if (battery_power < 1000)
                reference_power_level = 0;

            var rand = new Random();

            if (battery_power > 1000)
                utility_power.Text = "Power: 0";
            else
            {
                utility_power.Text = "Power: " + rand.Next(-10160, -10075).ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string DBPath = "C:\\Users\\nikgal-local\\Desktop\\multicon\\database.mdb";
            conn = new OleDbConnection("provider=Microsoft.Jet.OLEDB.4.0;" + "Data Source=" + DBPath);
            conn.Open();
            DateTime localDate = DateTime.Now;
            string sql_command = "INSERT INTO tabname_variable values ('"+localDate.ToString(new CultureInfo("ru-RU")).ToString()+"',67)";
            oledbAdapter.InsertCommand = new OleDbCommand(sql_command, conn);
            oledbAdapter.InsertCommand.ExecuteNonQuery();
            conn.Close();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {   
            foreach (var process in Process.GetProcessesByName("python"))
            {
                process.Kill();
            } 
        }
    }
}
