import asyncio
from datetime import datetime, timezone, timedelta
from openleadr import OpenADRServer
from functools import partial
import socket
import time
import threading

async def event_callback(ven_id, event_id, opt_type):
    print("new event_callback")
    print("ven_id = "+ven_id)
    print("event_id = "+event_id)
    print("opt_type = "+opt_type)

async def on_create_party_registration(registration_info):
    """
    Inspect the registration info and return a ven_id and registration_id.
    """
    if registration_info['ven_name'] == 'ven123':
        ven_id = 'ven_id_123'
        registration_id = 'reg_id_123'

        UDP_IP = "127.0.0.1"
        UDP_PORT = 8080
        message = "oadr:"
        message = message + "on_create_party_registration:"
        message = message + "{ven_name:"+ registration_info['ven_name'] + "," + "ven_id:"+ ven_id + "," + "registration_id:"+ registration_id + "}"
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(message.encode('ascii'), (UDP_IP, UDP_PORT))
        sock.close()

        return ven_id, registration_id
    else:
        return False

async def on_register_report(ven_id, resource_id, measurement, unit, scale,
                             min_sampling_interval, max_sampling_interval):
    """
    Inspect a report offering from the VEN and return a callback and sampling interval for receiving the reports.
    """
    print("new report has been registred")
    callback = partial(on_update_report, ven_id=ven_id, resource_id=resource_id, measurement=measurement)
    sampling_interval = min_sampling_interval
    return callback, sampling_interval

async def on_update_report(data, ven_id, resource_id, measurement):
    """
    Callback that receives report data from the VEN and handles it.
    """
    for time, value in data:
        print(f"Ven {ven_id} reported {measurement} = {value} at time {time} for resource {resource_id}")
        UDP_IP = "127.0.0.1"
        UDP_PORT = 8080
        message = "oadr:"
        message = message + "on_update_report:"
        message = message + "{ven_id:" + ven_id + "," + "measurement:"+ measurement + "," + "value:"+ str(value) + "}"
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(message.encode('ascii'), (UDP_IP, UDP_PORT))
        sock.close()

switch_pos = 0

def udp_listner(number):
    """
    A function that can be used by a thread
    """
    #print("New thread has been started...")
    global switch_pos

    UDP_IP = "127.0.0.1"
    UDP_PORT = 8083
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((UDP_IP,UDP_PORT))
    while True:
        msg, addr = sock.recvfrom(1024)
        if msg.decode("utf-8") == 'oadr:utility_switch:opened':
            switch_pos = 0
        else:
            switch_pos = 1
        server.add_event(ven_id='ven_id_123',
                         signal_name='simple',
                         signal_type='level',
                         intervals=[{'dtstart': datetime(2021, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
                                     'duration': timedelta(seconds=3),
                                     'signal_payload': switch_pos}],
                         callback=event_callback)

# Create the server object
server = OpenADRServer(vtn_id='myvtn',  http_port=8081, http_host='192.168.10.98')
                       #http_host='localhost')

# Add the handler for client (VEN) registrations
server.add_handler('on_create_party_registration', on_create_party_registration)

# Add the handler for report registrations from the VEN
server.add_handler('on_register_report', on_register_report)

# Add a prepared event for a VEN that will be picked up when it polls for new messages.
server.add_event(ven_id='ven_id_123',
                 signal_name='simple',
                 signal_type='level',
                 intervals=[{'dtstart': datetime(2021, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
                             'duration': timedelta(seconds=3),
                             'signal_payload': 1}],
                 callback=event_callback)

my_thread = threading.Thread(target=udp_listner, args=(0,))
my_thread.start()

# Run the server on the asyncio event loop
loop = asyncio.get_event_loop()
loop.create_task(server.run())
loop.run_forever()