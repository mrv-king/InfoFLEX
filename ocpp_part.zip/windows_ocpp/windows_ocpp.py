import asyncio
from os import system
import logging
import array
import websockets
from datetime import datetime

from threading import Timer

from ocpp.routing import on, after
from ocpp.v201 import ChargePoint as cp
from ocpp.v201 import call_result, call

import socket
import time
import threading

logging.basicConfig(level=logging.INFO)

class ChargePoint(cp):
    @on('BootNotification')
    async def on_boot_notification(self, charging_station, reason, **kwargs):
        UDP_IP = "127.0.0.1"
        UDP_PORT = 8080
        message = "ocpp:"
        message = message + "bootNotification:"
        message = message + "{model:"+charging_station["model"] + "," + "vendor_name:"+ charging_station["vendor_name"] + "} at time "+ datetime.utcnow().isoformat()
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(message.encode('ascii'), (UDP_IP, UDP_PORT))
        sock.close()
        print ("boot_notification")
        return call_result.BootNotificationPayload(
            current_time=datetime.utcnow().isoformat(),
            interval=10,
            status='Accepted'
        )

    @on('StatusNotification')
    async def on_status_notification(self, timestamp, connector_status, evse_id, connector_id, **kwargs):
        return call_result.StatusNotificationPayload()

    @on('TransactionEvent')
    async def on_transaction_event_request(self, event_type, timestamp, trigger_reason, seq_no, transaction_info, **kwargs):
        priority = 0
        if trigger_reason == 'Authorized':
            priority = 10

            UDP_IP = "127.0.0.1"
            UDP_PORT = 8080
            message = "ocpp:"
            message = message + "transactionEvent:"
            message = message + "{trigger_reason:"+trigger_reason+",chargingState:"+ transaction_info["charging_state"] +"} at time "+timestamp
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.sendto(message.encode('ascii'), (UDP_IP, UDP_PORT))
            sock.close()
        else:
            priority = 0

        return call_result.TransactionEventPayload(
            charging_priority = priority
            )       

    @on('Heartbeat')
    async def on_heartbeat_rquest(self):
        return call_result.HeartbeatPayload(
                current_time = datetime.utcnow().isoformat()
            )

    @on('SetVariables')
    async def on_set_variables(self, set_variable_data, **kwargs):   
        UDP_IP = "127.0.0.1"
        UDP_PORT = 8080
        message = "ocpp:"
        message = message + "setVariables:"
        message = message + "{from:"+set_variable_data[0].get('component').get('name')+",variable:"+set_variable_data[0].get('variable').get('name') + ",attribute_value:"+ set_variable_data[0].get('attribute_value') + "}"
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(message.encode('ascii'), (UDP_IP, UDP_PORT))
        sock.close()

        set_variable_data[0].pop('attribute_value')
        c = {'attribute_status': 'Accepted'}
        set_variable_data[0].update(c)

        return call_result.SetVariablesPayload(
            set_variable_result = set_variable_data
        )

    @on('GetVariables')
    async def on_get_variables(self, get_variable_data, **kwargs):
        c = {'attribute_status': 'Accepted'}
        value = {'attribute_value': 'value_example'}
        get_variable_data[0].update(c)
        get_variable_data[0].update(value)
        return call_result.GetVariablesPayload(
            get_variable_result = get_variable_data
        )

    async def send_charging_profile_request(self):
        request = call.SetChargingProfilePayload(
                evse_id = 1,
                charging_profile = {
                    'id': 0,
                    'stackLevel': 5,
                    'chargingProfilePurpose': 'TxProfile',
                    'chargingProfileKind': 'Relative',
                    'chargingSchedule': [
                        {'id': 1,
                         'chargingRateUnit':'A',
                         'chargingSchedulePeriod': [{
                             'startPeriod':10, 
                             'limit': 0.9
                             }]
                         }]
                }
            )
        response = await self.call(request)
        
    async def set_variables(self):
        global power_ref_value
        request = call.SetVariablesPayload(
            set_variable_data=[
                {'component': {'name': 'Robotino#1'},
                'variable': {'name': 'power'},
                'attribute_value': str(power_ref_value)}
            ]
        )
        #print ("\n\n\n set _variable command \n\n\n")
        response = await self.call(request)



async def on_connect(websocket, path):
    """ For every new charge point that connects, create a ChargePoint
    instance and start listening for messages.
    """
    try:
        requested_protocols = websocket.request_headers[
            'Sec-WebSocket-Protocol']
    except KeyError:
        logging.info("Client hasn't requested any Subprotocol. "
                 "Closing Connection")
    if websocket.subprotocol:
        logging.info("Protocols Matched: %s", websocket.subprotocol)
    else:
        # In the websockets lib if no subprotocols are supported by the
        # client and the server, it proceeds without a subprotocol,
        # so we have to manually close the connection.
        logging.warning('Protocols Mismatched | Expected Subprotocols: %s,'
                        ' but client supports  %s | Closing connection',
                        websocket.available_subprotocols,
                        requested_protocols)
        return await websocket.close()
    charge_point_id = path.strip('/')
    cp = ChargePoint(charge_point_id, websocket)
    #await cp.start()
    await asyncio.gather(cp.start(), execute_cmd(cp))

def udp_listner(number):
    """
    A function that can be used by a thread
    """
    #print("New thread has been started...")
    global update_value
    global power_ref_value
    
    decoded_msg = ""
   
    UDP_IP = "127.0.0.1"
    UDP_PORT = 8082
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((UDP_IP,UDP_PORT))
    while True:
        msg, addr = sock.recvfrom(1024)
        decoded_msg = msg.decode("utf-8")
        if decoded_msg.find("ocpp:set_variable:power:") != -1:
            power_ref_value = int(decoded_msg[len("ocpp:set_variable:power:"):None]) 
            update_value = True
        else:
            print ("something is wrong...")
            update_value = False 

update_value = False
power_ref_value = 0

async def main():
    my_thread_1 = threading.Thread(target=udp_listner, args=(0,))
    my_thread_1.start()
    server = await websockets.serve(
        on_connect,
        '192.168.10.98',
        8080,
        subprotocols=['ocpp2.0.1']
    )
    logging.info("WebSocket Server Started")
    await server.wait_closed()

async def execute_cmd(obj):
    global update_value
    while True:
        if update_value == True:
            #await obj.send_charging_profile_request()
            await obj.set_variables()
            update_value = False
        await asyncio.sleep(1)

if __name__ == '__main__':
    asyncio.run(main())



